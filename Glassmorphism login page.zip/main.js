// Login Form Interactive Functionality
class LoginForm {
    constructor() {
        this.form = document.getElementById('loginForm');
        this.emailInput = document.getElementById('email');
        this.passwordInput = document.getElementById('password');
        this.passwordToggle = document.getElementById('passwordToggle');
        this.loginBtn = document.getElementById('loginBtn');
        this.errorMessage = document.getElementById('errorMessage');
        this.successMessage = document.getElementById('successMessage');
        
        this.init();
    }

    init() {
        this.createParticles();
        this.initAnimations();
        this.bindEvents();
        this.initValidation();
    }

    // Create floating particles for background effect
    createParticles() {
        const particlesContainer = document.getElementById('particles');
        const particleCount = 50;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 20 + 's';
            particle.style.animationDuration = (Math.random() * 10 + 15) + 's';
            particlesContainer.appendChild(particle);
        }
    }

    // Initialize entrance animations
    initAnimations() {
        // Animate main container
        anime({
            targets: '.fade-in',
            opacity: [0, 1],
            translateY: [30, 0],
            duration: 800,
            easing: 'easeOutQuart',
            delay: 200
        });

        // Animate staggered elements
        anime({
            targets: '.stagger',
            opacity: [0, 1],
            translateY: [20, 0],
            duration: 600,
            easing: 'easeOutQuart',
            delay: anime.stagger(100, {start: 400})
        });

        // Animate brand text with gradient effect
        anime({
            targets: '.brand h1',
            scale: [0.8, 1],
            duration: 1000,
            easing: 'easeOutElastic(1, .8)',
            delay: 600
        });
    }

    // Bind all event listeners
    bindEvents() {
        // Form submission
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));

        // Password visibility toggle
        this.passwordToggle.addEventListener('click', () => this.togglePassword());

        // Input focus animations
        this.emailInput.addEventListener('focus', () => this.animateInputFocus(this.emailInput));
        this.passwordInput.addEventListener('focus', () => this.animateInputFocus(this.passwordInput));

        // Input blur animations
        this.emailInput.addEventListener('blur', () => this.animateInputBlur(this.emailInput));
        this.passwordInput.addEventListener('blur', () => this.animateInputBlur(this.passwordInput));

        // Real-time validation
        this.emailInput.addEventListener('input', () => this.validateEmail());
        this.passwordInput.addEventListener('input', () => this.validatePassword());

        // Social login buttons
        document.querySelectorAll('.social-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleSocialLogin(e));
        });

        // Forgot password link
        document.querySelector('.forgot-password').addEventListener('click', (e) => {
            e.preventDefault();
            this.showComingSoon('Password reset feature');
        });

        // Sign up link
        document.querySelector('.signup-link a').addEventListener('click', (e) => {
            e.preventDefault();
            this.showComingSoon('Registration feature');
        });
    }

    // Initialize form validation
    initValidation() {
        this.emailInput.setAttribute('placeholder', ' ');
        this.passwordInput.setAttribute('placeholder', ' ');
    }

    // Handle form submission
    async handleSubmit(e) {
        e.preventDefault();
        
        const email = this.emailInput.value.trim();
        const password = this.passwordInput.value;

        // Show loading state
        this.showLoading(true);
        this.hideMessages();

        // Simulate API call
        try {
            await this.simulateLogin(email, password);
            this.showSuccess();
        } catch (error) {
            this.showError(error.message);
        } finally {
            this.showLoading(false);
        }
    }

    // Simulate login API call
    simulateLogin(email, password) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Demo validation - in real app, this would be an API call
                if (email === 'demo@example.com' && password === 'password123') {
                    resolve({ success: true });
                } else if (email && password) {
                    reject(new Error('Invalid credentials'));
                } else {
                    reject(new Error('Please fill in all fields'));
                }
            }, 2000);
        });
    }

    // Toggle password visibility
    togglePassword() {
        const isPassword = this.passwordInput.type === 'password';
        this.passwordInput.type = isPassword ? 'text' : 'password';
        
        // Animate icon change
        anime({
            targets: this.passwordToggle,
            scale: [1, 0.8, 1],
            duration: 300,
            easing: 'easeOutQuart',
            complete: () => {
                this.passwordToggle.className = isPassword ? 
                    'fas fa-eye-slash password-toggle' : 
                    'fas fa-eye password-toggle';
            }
        });
    }

    // Animate input focus
    animateInputFocus(input) {
        anime({
            targets: input,
            scale: [1, 1.02, 1],
            duration: 300,
            easing: 'easeOutQuart'
        });
    }

    // Animate input blur
    animateInputBlur(input) {
        anime({
            targets: input,
            scale: [1, 0.98, 1],
            duration: 200,
            easing: 'easeOutQuart'
        });
    }

    // Validate email format
    validateEmail() {
        const email = this.emailInput.value.trim();
        const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        
        this.setInputValidation(this.emailInput, isValid || email === '');
        return isValid;
    }

    // Validate password strength
    validatePassword() {
        const password = this.passwordInput.value;
        const isValid = password.length >= 6;
        
        this.setInputValidation(this.passwordInput, isValid || password === '');
        return isValid;
    }

    // Set input validation state
    setInputValidation(input, isValid) {
        if (isValid) {
            input.style.borderColor = 'rgba(16, 185, 129, 0.5)';
            input.style.boxShadow = '0 0 0 4px rgba(16, 185, 129, 0.1)';
        } else {
            input.style.borderColor = 'rgba(239, 68, 68, 0.5)';
            input.style.boxShadow = '0 0 0 4px rgba(239, 68, 68, 0.1)';
        }
    }

    // Show/hide loading state
    showLoading(isLoading) {
        if (isLoading) {
            this.loginBtn.classList.add('loading');
            this.loginBtn.innerHTML = '';
            this.loginBtn.disabled = true;
        } else {
            this.loginBtn.classList.remove('loading');
            this.loginBtn.innerHTML = 'Sign In';
            this.loginBtn.disabled = false;
        }
    }

    // Show error message
    showError(message) {
        this.errorMessage.querySelector('span').textContent = message;
        this.errorMessage.classList.add('show');
        
        anime({
            targets: this.errorMessage,
            opacity: [0, 1],
            translateY: [-10, 0],
            duration: 300,
            easing: 'easeOutQuart'
        });

        // Auto-hide after 5 seconds
        setTimeout(() => this.hideMessages(), 5000);
    }

    // Show success message
    showSuccess() {
        this.successMessage.classList.add('show');
        
        anime({
            targets: this.successMessage,
            opacity: [0, 1],
            translateY: [-10, 0],
            duration: 300,
            easing: 'easeOutQuart'
        });

        // Simulate redirect after 2 seconds
        setTimeout(() => {
            this.showComingSoon('Dashboard page');
        }, 2000);
    }

    // Hide all messages
    hideMessages() {
        this.errorMessage.classList.remove('show');
        this.successMessage.classList.remove('show');
    }

    // Handle social login
    handleSocialLogin(e) {
        const provider = e.currentTarget.classList.contains('google') ? 'Google' :
                        e.currentTarget.classList.contains('facebook') ? 'Facebook' : 'GitHub';
        
        // Animate button click
        anime({
            targets: e.currentTarget,
            scale: [1, 0.95, 1],
            duration: 200,
            easing: 'easeOutQuart'
        });

        this.showComingSoon(`${provider} login`);
    }

    // Show "coming soon" message for demo features
    showComingSoon(feature) {
        // Create modal overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
        `;

        const modal = document.createElement('div');
        modal.style.cssText = `
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
            padding: 32px;
            text-align: center;
            max-width: 400px;
            margin: 20px;
            transform: scale(0.8);
        `;

        modal.innerHTML = `
            <div style="color: #f8fafc; margin-bottom: 16px;">
                <i class="fas fa-info-circle" style="font-size: 3rem; color: #f59e0b; margin-bottom: 16px;"></i>
                <h3 style="font-size: 1.5rem; margin-bottom: 8px;">Coming Soon</h3>
                <p style="color: #cbd5e1; margin-bottom: 24px;">${feature} is currently in development and will be available soon!</p>
                <button onclick="this.closest('.modal-overlay').remove()" style="
                    background: linear-gradient(135deg, #f59e0b, #d97706);
                    border: none;
                    border-radius: 8px;
                    padding: 12px 24px;
                    color: white;
                    font-weight: 600;
                    cursor: pointer;
                ">Got it</button>
            </div>
        `;

        overlay.className = 'modal-overlay';
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        // Animate modal appearance
        anime({
            targets: overlay,
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutQuart'
        });

        anime({
            targets: modal,
            scale: [0.8, 1],
            duration: 400,
            easing: 'easeOutElastic(1, .8)',
            delay: 100
        });
    }

    // Add keyboard navigation support
    addKeyboardSupport() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target.type !== 'submit') {
                const formElements = Array.from(this.form.querySelectorAll('input, button'));
                const currentIndex = formElements.indexOf(e.target);
                const nextElement = formElements[currentIndex + 1];
                
                if (nextElement) {
                    e.preventDefault();
                    nextElement.focus();
                }
            }
        });
    }
}

// Initialize login form when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = new LoginForm();
    
    // Add some additional interactive effects
    
    // Mouse move effect on container
    const container = document.querySelector('.login-container');
    let mouseX = 0;
    let mouseY = 0;
    
    document.addEventListener('mousemove', (e) => {
        mouseX = (e.clientX / window.innerWidth) * 2 - 1;
        mouseY = (e.clientY / window.innerHeight) * 2 - 1;
        
        container.style.transform = `translateY(-5px) rotateX(${mouseY * 5}deg) rotateY(${mouseX * 5}deg)`;
    });
    
    // Add hover effect to social buttons
    document.querySelectorAll('.social-btn').forEach(btn => {
        btn.addEventListener('mouseenter', () => {
            anime({
                targets: btn,
                scale: 1.05,
                duration: 200,
                easing: 'easeOutQuart'
            });
        });
        
        btn.addEventListener('mouseleave', () => {
            anime({
                targets: btn,
                scale: 1,
                duration: 200,
                easing: 'easeOutQuart'
            });
        });
    });
    
    // Add focus animations to form inputs
    document.querySelectorAll('.form-group input').forEach(input => {
        input.addEventListener('focus', () => {
            anime({
                targets: input,
                boxShadow: '0 0 0 4px rgba(245, 158, 11, 0.2)',
                duration: 300,
                easing: 'easeOutQuart'
            });
        });
        
        input.addEventListener('blur', () => {
            anime({
                targets: input,
                boxShadow: '0 0 0 0px rgba(245, 158, 11, 0)',
                duration: 300,
                easing: 'easeOutQuart'
            });
        });
    });
    
    // Add particle trail effect
    document.addEventListener('mousemove', (e) => {
        if (Math.random() > 0.95) {
            const particle = document.createElement('div');
            particle.style.cssText = `
                position: fixed;
                width: 2px;
                height: 2px;
                background: rgba(245, 158, 11, 0.6);
                border-radius: 50%;
                pointer-events: none;
                left: ${e.clientX}px;
                top: ${e.clientY}px;
                z-index: 9999;
            `;
            document.body.appendChild(particle);
            
            anime({
                targets: particle,
                scale: [1, 0],
                opacity: [1, 0],
                duration: 1000,
                easing: 'easeOutQuart',
                complete: () => particle.remove()
            });
        }
    });
});

// Add some utility functions for enhanced UX
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add performance optimization
if ('requestIdleCallback' in window) {
    requestIdleCallback(() => {
        // Preload images or perform non-critical tasks
        const img = new Image();
        img.src = 'resources/hero-background.png';
    });
}

// Add accessibility improvements
document.addEventListener('DOMContentLoaded', () => {
    // Add focus indicators for keyboard navigation
    const style = document.createElement('style');
    style.textContent = `
        *:focus {
            outline: 2px solid #f59e0b;
            outline-offset: 2px;
        }
        
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
    `;
    document.head.appendChild(style);
});